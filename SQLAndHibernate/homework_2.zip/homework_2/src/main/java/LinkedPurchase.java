import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "LinkedPurchaseList")
@Entity
public class LinkedPurchase {

    @EmbeddedId
    private LinkedPurchaseKey key;

    @Id
    private int studentId;

    @Id
    private int courseId;

    public LinkedPurchaseKey getKey() {
        return key;
    }

    public void setKey(LinkedPurchaseKey key) {
        this.key = key;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }
}
